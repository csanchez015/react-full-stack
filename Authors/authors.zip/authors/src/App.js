import {Routes, Route, Navigate} from 'react-router-dom';
import './App.css';
import Main from './views/Main';
import NewAuthor from './components/AuthorForm';
import UpdateAuthor from './views/EditAuthor';

function App() {
  return (
    <>
    <div className="container">
      <nav className="w-100 navbar navbar-expand-lg justify-content-center mb-4">
        <h1 className="navbar-brand mb-0">Favorite Authors</h1>
      </nav>
      <Routes>
        <Route path='/' element={<Navigate to='/authors' replace/>} />
        <Route path='/authors' element={<Main/>} />
        <Route path='/authors/:_id/update' element={<UpdateAuthor/>} />
        <Route path='/authors/create' element={<NewAuthor/>} />
      </Routes>
    </div>
    
    </>
    
  );
}

export default App;
