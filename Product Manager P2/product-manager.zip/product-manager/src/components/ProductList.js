import React from 'react';
import { Link } from 'react-router-dom';

const ProductList = (props) => {
    return (
        <div className="w-50 mx-auto text-center">
            <h1> All Products</h1>
            {
                props.allProducts.map((product, i) => { 
                    const { _id, title } = product;
                    return (
                        <div key={i} className="shadow mb-3 rounded p-3">
                            <Link to={`/${_id}`}><h3>{title}</h3></Link>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default ProductList;