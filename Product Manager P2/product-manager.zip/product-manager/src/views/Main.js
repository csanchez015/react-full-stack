import { useState, useEffect } from 'react';
import axios from 'axios';
import ProductList from '../components/ProductList';
import ProductForm from '../components/ProductForm';



const Main = (props) => {
    const [allProducts, setAllProducts] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then(res => {
                console.log(res);
                setAllProducts(res.data);
            })
            .catch(err => {
                console.log(err);
            })
    }, [])

    return (
        <div>
            <ProductForm />
            <hr />
            {<ProductList allProducts={allProducts} />}
        </div>
    )



}

export default Main;